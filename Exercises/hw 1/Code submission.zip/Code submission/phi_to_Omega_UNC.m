function [ Omega ] = phi_to_Omega_UNC (phi, K)
Omega = 0.5 * K* phi^2 ;
end