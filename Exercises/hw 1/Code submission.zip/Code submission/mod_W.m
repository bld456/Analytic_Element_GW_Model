function [modW] = mod_W (W)
modW = (W* conj(W));
end