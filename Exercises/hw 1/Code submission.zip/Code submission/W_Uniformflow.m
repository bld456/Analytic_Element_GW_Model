function [ W ] = W_Uniformflow (W0)
W= W0/2;
end