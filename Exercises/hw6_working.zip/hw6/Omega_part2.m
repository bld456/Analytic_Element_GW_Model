function [Omega] = Omega_part2(z,s,w0, rLakes, refZ,refPhi )
%OMEGA_PART2 Summary of this function goes here
%   Detailed explanation goes here

rsq1  = rLakes(1) * conj(rLakes(1));
rsq2  = rLakes(2) * conj(rLakes(2));


Omega = 0;
Omega = Omega + -w0 *z ;
Omega = Omega + s(length(s));


if ((z-refZ(1))*conj(z-refZ(1)) ) < rsq1 
    
    Omega =Omega+0;% refPhi(1);
    
else if ((z-refZ(2))*conj(z-refZ(2)) ) < rsq2 
    Omega = Omega+0;%refPhi(2);
    
else
Omega = Omega + conj(w0) * rLakes(1)^2/(z - refZ(1));
Omega = Omega + (s(1) /(2*pi)) * log((z - refZ(1))/rLakes(1));





Omega = Omega + (s(2) /(2*pi)) * log((z - refZ(2))/rLakes(2));
Omega = Omega + conj(w0) * rLakes(2)^2/(z - refZ(2));

end



end

