Qx0 =.4;
Qy0 =0;
w0 = Qx0 + 1i*Qy0;

nLakes = 2;
refZ = [-100 + 100*1i, 100 + -100*1i,1000];
rl = [100,100];


Phi = [100,100,50];

A = Populate_A(nLakes,rl,refZ);
b = Populat_b(nLakes,w0, rl,refZ,Phi);

s = A\b;


% ContourMe_flow_net(-300,300,200,-300,300,200, @(z)Omega_part2(z,s,w0,rl,refZ,Phi),30);
%ContourMe_R_int(-1300,300,200,-300,300,200, @(z)real(Omega_part2(z,s,w0,rl,refZ,Phi)),30);
%
colorbar
% %far field condition
% %alpha_rough= alpha_given_Q(zl,rl,Ql,Phi, w0);
% alpha_rough = [0;0];
 %ContourMe_flow_net(-300,300,200,-300,300,200, @(z)Omega_total(z,w0,refZ,rl,s,Phi,nLakes),100);
 ContourMe_R_int( -300,300,200,-300,300,200,  @(z)real(Omega_total(z,w0,refZ,rl,s,Phi,nLakes)),100  );
 colorbar