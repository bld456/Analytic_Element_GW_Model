function [A] = Populate_A(nLakes, rlakes,refZ )
%POPULATE_A Summary of this function goes here
%   Detailed explanation goes here
A = zeros(nLakes+1, nLakes + 1);
A(:, nLakes +1 ) = 1;

for row = 1:nLakes+1
    for col = 1:nLakes
    if row == nLakes +1
        A(row,col)  = real((1/2*pi) * log((refZ(row) -refZ(col))/rlakes(col)));
   
    else
        
        A(row,col)  = real((1/2*pi) * log((refZ(row) + rlakes(row)-refZ(col))/rlakes(col)));
    end
    
    
    end
end



