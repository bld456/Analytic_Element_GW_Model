function [b] = Populat_b(nLakes, W0, rLakes, refZ, refPhi )
%POPULAT_B Summary of this function goes here
%   Detailed explanation goes here
b = zeros(nLakes +1,1);

    
   b(1) = real(W0 * (rLakes(1) +refZ(1))+refPhi(1) - conj(W0)*rLakes(1) - conj(W0)*rLakes(2)^2 /(refZ(1) + rLakes(1) - refZ(2))  );
     b(2) = real(W0 * (rLakes(2) +refZ(2))+refPhi(2) - conj(W0)*rLakes(2) - conj(W0)*rLakes(1)^2 /(refZ(2) + rLakes(2) - refZ(1))  );
      b(3) = real(W0 * refZ(3) +refPhi(3) - conj(W0)*rLakes(1)^2 /(refZ(3) - refZ(1)) - conj(W0)*rLakes(2)^2 /(refZ(3)  - refZ(2))  );
    
    
    
    

end

