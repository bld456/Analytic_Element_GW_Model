function [z] = z_of_Z(Z,zm,rm)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


z=Z *rm + zm ;
end

