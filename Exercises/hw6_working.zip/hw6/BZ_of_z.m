function [Z] = BZ_of_z(z,zm,rm)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


Z = (z-zm)/rm ;
end

