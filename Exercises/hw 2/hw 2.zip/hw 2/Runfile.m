

Q = 100;
Qx0 = 1 ;
d= Q /(2*pi*Qx0);


l = 50;
rw = 0.2; %m

a= .6;
b= 50 ;
%Q  = Qx0 * b * pi *( 2*pi - atan((b+d)/l) - atan((b-d)/l))^-1; %m^2/ d

z1= 0;
z2= -2*d;


ContourMe_flow_net(-l,l,50,-(b+5),(b+5),50,@(z)Omega_total(z,Qx0,Q,z1,z2,rw),30);
