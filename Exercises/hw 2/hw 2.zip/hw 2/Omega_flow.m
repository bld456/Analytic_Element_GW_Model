function [ Omega ] = Omega_Uniformflow (W0,z)
Omega = -W0*z/2
end